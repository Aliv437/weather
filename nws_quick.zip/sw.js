const CACHE = 'nws-v1';
const ASSETS = ['/', '/index.html', '/style.css', '/app.js', '/manifest.webmanifest'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', e => self.clients.claim());

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  const isApi = url.pathname.startsWith('/points') ||
                url.pathname.includes('/forecast') ||
                url.pathname.includes('/alerts') ||
                url.host.endsWith('api.weather.gov');
  if (isApi) {
    e.respondWith((async () => {
      try {
        const res = await fetch(e.request);
        const cache = await caches.open(CACHE);
        cache.put(e.request, res.clone());
        return res;
      } catch {
        const cached = await caches.match(e.request);
        if (cached) return cached;
        throw new Error('Offline and no cached data.');
      }
    })());
  } else {
    e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
  }
});